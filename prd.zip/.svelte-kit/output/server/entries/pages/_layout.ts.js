const ssr = false;
const load = () => ({});
export {
  load,
  ssr
};

import * as universal from '../entries/pages/recurring/_page.ts.js';

export const index = 5;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/recurring/_page.svelte.js')).default;
export { universal };
export const universal_id = "src/routes/recurring/+page.ts";
export const imports = ["_app/immutable/nodes/5.BoCygumc.js","_app/immutable/chunks/scheduler.DrDOSCrp.js","_app/immutable/chunks/index.BljkXhbZ.js","_app/immutable/chunks/index.D0tE5qX2.js","_app/immutable/chunks/Icon.C5GaHf5i.js","_app/immutable/chunks/format.DS6QGfyw.js","_app/immutable/chunks/download.BFTxnY3b.js"];
export const stylesheets = [];
export const fonts = [];

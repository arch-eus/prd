

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.DRZjewoY.js","_app/immutable/chunks/scheduler.DrDOSCrp.js","_app/immutable/chunks/index.BljkXhbZ.js","_app/immutable/chunks/stores.BsB0SR2j.js","_app/immutable/chunks/entry.Q5SuwGPT.js","_app/immutable/chunks/index.D0tE5qX2.js"];
export const stylesheets = [];
export const fonts = [];

const handle = async ({ event, resolve }) => {
  return resolve(event);
};
export {
  handle
};

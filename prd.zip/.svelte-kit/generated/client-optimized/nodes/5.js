import * as universal from "../../../../src/routes/recurring/+page.ts";
export { universal };
export { default as component } from "../../../../src/routes/recurring/+page.svelte";
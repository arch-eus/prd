top bar (always on)
- timer
- (future navigation)
- search
- voice + create task

menu bar (shown if place, shown when approached? hidden when wanted)
- task views
- notes export
- changelog link (to modal)
- shortcuts

note bar (only shown when approached, w/ option for always visible)
- 

main view
- week ahead? or move this to top bar?

arrows for brwsing through days (can be used for notes navigtion as well)
autohide or fix sidebars (incl notebar right)
search in notes and tasks
no drag 'n drop
search only works in overview, yet not logical to keep the calendar view when only today is searched (not completed)
from search result, when clicking date, exit search
no strikethrough font for completed tasks only different circle/checkmark
from recurring, completed and logbook pages, edit task (created on, completed on?)

for a recurring task - when completed update interval?
editing a recurring task - all, future or this one?
task statuses (instead of comparing dates?): done, due (today), planned
which dates are stored (created, modified,...)
snooze to somewhere next week (next monday + random between 1-5) & snooze to somewhere later (next monday + random 5-30) - only from edit form
how does delete work on mobile? hover buttons? swipe actions? swipe for short snooze? with undo 
notebar: add timestamp with title (on enter) section with bullets (monaco style?), end section on ---?
note export from to in md- format?
arrows do not work for selecting existing tags in newtaskform
ctrl+enter instead of enter
strikethrough font
checkbox in new task form is not binded?
version tracking + changelog
speech only works in edge? add task today, no intelligence
date formats are US style everywhere

completed tasks in the past are not shown in the completed view nor logbook (completed date issue, as this is not today?)

search for notes? results page? detail?
how are tasks sorted? oldest first? recurring first? overdue?

statistics?

add 20' color timer top left 's' for start/reset

logbook table in edit mode?

flow for notes, so only timestamps
can be hidden for privacy

// Server-side hooks
export const handle = async ({ event, resolve }) => {
  return resolve(event);
};
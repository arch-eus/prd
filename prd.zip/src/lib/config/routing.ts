// Routing configuration
export const routingConfig = {
  ssr: false,
  prerender: false
};
// This file is deprecated, moved to task/index.ts
export { taskStore, filteredTasks, completedTasks } from './task';
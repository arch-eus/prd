<div class="grid grid-cols-7 gap-1 mb-1 text-sm font-medium text-navy-400 font-jetbrains-mono">
  {#each ['M', 'T', 'W', 'T', 'F', 'S', 'S'] as day}
    <div class="text-center p-2">{day}</div>
  {/each}
</div>
// Simple static load function that returns empty props
export const load = () => ({});
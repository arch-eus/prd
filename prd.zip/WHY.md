IDEA
primary: build a personal task manager
- tasks to track (logbook) - car maintenance
- follow-up on important stuff (to avoid postits) - commitments 
- schedule recurring tasks that do not have visual hints - clean filter of machine Y
secondayr: learn svelte & webapps & AI
tert: stepping stone for AI-agents later (taking up and creating tasks)


quick notes
- one daily note that allows URLs and screenshots + STT

success:
- drastically limit the paper notes on my desk, that I throw away anyhow
- more regular follow-up




you need to think and be aware
not everything will end up here
complementary with paper

Out-of-scope
- calendar views (short term only)
- notetaking (knowledge mgt is someting different, yet free format is needed)
- reminders (the habit is looking at the list and planning, not being chased)
- priorities (they shift, you recalculate/sense faster)
- deadlines (you know them, plan ahead instead, they also change)


technicalities
- local first
- offline capable
- mobile - on-the-go
- data export
- webapp for accessability
- no login, yet private
- keyboard speed of light